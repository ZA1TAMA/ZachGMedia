Thank you for downloading my blue fire after effects template!

Be sure to share it with all your video producer friends and create some EPIC LEVEL CONTENT!

Zach Genest
zgcreation.com